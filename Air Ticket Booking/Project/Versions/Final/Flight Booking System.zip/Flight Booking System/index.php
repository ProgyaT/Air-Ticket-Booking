<?php
header("Location: http://localhost/Projects/Flight%20Booking%20System/login.php");